package com.apexbetguide.app

import android.os.Bundle
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.apexbetguide.app.admob.AdMobManager
import com.apexbetguide.app.databinding.ActivityMainBinding
import com.apexbetguide.app.ui.screens.HomeFragment
import com.apexbetguide.app.ui.screens.NewsFragment
import com.apexbetguide.app.ui.screens.PredictionsFragment
import com.apexbetguide.app.ui.screens.SettingsFragment
import com.apexbetguide.app.ui.screens.TipsFragment

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    lateinit var adMobManager: AdMobManager
        private set

    private var currentTabId: Int = R.id.nav_home

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Initialize AdMobManager
        adMobManager = AdMobManager(this)

        // Setup fixed bottom banner ad (loads on app start)
        adMobManager.setupBottomBanner(this, binding.bannerAdContainer)

        // Safe Back-Press handling: NEVER trigger interstitial ads on back press
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (currentTabId != R.id.nav_home) {
                    // Navigate back to Home tab without showing any ad
                    binding.bottomNavigation.selectedItemId = R.id.nav_home
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })

        // Setup 5 tabs bottom navigation
        setupBottomNavigation()

        // Load initial screen
        if (savedInstanceState == null) {
            replaceFragment(HomeFragment())
        }
    }

    private fun setupBottomNavigation() {
        binding.bottomNavigation.setOnItemSelectedListener { item ->
            if (item.itemId == currentTabId) return@setOnItemSelectedListener false

            currentTabId = item.itemId
            val fragment: Fragment = when (item.itemId) {
                R.id.nav_home -> HomeFragment()
                R.id.nav_predictions -> PredictionsFragment()
                R.id.nav_tips -> TipsFragment()
                R.id.nav_news -> NewsFragment()
                R.id.nav_settings -> SettingsFragment()
                else -> HomeFragment()
            }

            replaceFragment(fragment)

            // Notify AdMob manager of tab change to evaluate safe interstitial logic
            adMobManager.onTabSwitched(this)
            true
        }
    }

    private fun replaceFragment(fragment: Fragment) {
        supportFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .commit()
    }
}
