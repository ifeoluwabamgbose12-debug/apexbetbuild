# Apex Bet Guide - Complete Android Studio Project

This is a complete, production-ready Android Studio project for **Apex Bet Guide** (`com.apexbetguide.app`).

## AdMob IDs Configured:
- **App ID**: `ca-app-pub-2988909177112608~XXXXXXXXXX`
- **Banner Ad**: `ca-app-pub-2988909177112608/3929862446`
- **Interstitial Ad**: `ca-app-pub-2988909177112608/8014868105`
- **Rewarded Ad**: `ca-app-pub-2988909177112608/2511259988`

---

## Safe AdMob Settings Implemented to Prevent Account Bans:
1. **Banner Ad**: Anchored in fixed container at bottom, automatically loaded on launch.
2. **Interstitial Ad**: Preloaded in background. STRICT rules enforced in `AdMobManager.kt`:
   - Shows **ONLY** after 2nd tab click (`tabSwitchCount >= 2`).
   - Maximum once every **120 seconds** (`MIN_INTERSTITIAL_INTERVAL_MS = 120_000L`).
   - Minimum **5-second delay** after app launch before first interstitial can be shown.
   - **NEVER** shown on back press (strictly enforced via `onBackPressedDispatcher`).
3. **Rewarded Ad**: Triggered **ONLY** when user explicitly taps the "Unlock VIP Tips Today" button.
4. **Test Device Configuration**: Test emulator and device IDs pre-configured in `ApexBetApplication.kt`.

---

## How to Build the Android App Bundle (.aab) for Google Play:

1. **Extract this ZIP** into your local workspace.
2. Open **Android Studio** (Koala / Jellyfish / Iguana or later).
3. Select **File > Open** and choose the extracted folder.
4. Wait for Gradle Sync to complete.
5. In `app/src/main/res/values/strings.xml`, replace `ca-app-pub-2988909177112608~XXXXXXXXXX` with your actual AdMob App ID from your AdMob console (if you have not done so already).
6. Go to **Build > Generate Signed Bundle / APK...**
7. Choose **Android App Bundle (.aab)** and click **Next**.
8. Select or create your release Keystore and key alias.
9. Select **release** build variant and click **Create**.
10. The generated `.aab` file is in `app/release/app-release.aab`, ready for Google Play Console upload!
