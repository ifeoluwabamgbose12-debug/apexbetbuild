package com.apexbetguide.app.admob

import android.app.Activity
import android.content.Context
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.widget.FrameLayout
import com.apexbetguide.app.R
import com.google.android.gms.ads.AdError
import com.google.android.gms.ads.AdListener
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.AdSize
import com.google.android.gms.ads.AdView
import com.google.android.gms.ads.FullScreenContentCallback
import com.google.android.gms.ads.LoadAdError
import com.google.android.gms.ads.interstitial.InterstitialAd
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback
import com.google.android.gms.ads.rewarded.RewardedAd
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback

/**
 * AdMobManager encapsulates all Google AdMob ad units with STRICT SAFE SETTINGS:
 * 1. Banner ad fixed at bottom, loads automatically on app start.
 * 2. Interstitial ad: preloaded in background, shown ONLY after 2nd tab click
 *    AND with a minimum interval of 120 seconds between impressions.
 * 3. Initial 5-second loading delay before the first interstitial can ever appear.
 * 4. Interstitials are NEVER shown on back press (strictly prohibited by Google Play policy).
 * 5. Rewarded ad: triggered EXCLUSIVELY by user clicking "Unlock VIP Tips Today".
 */
class AdMobManager(private val context: Context) {

    private var interstitialAd: InterstitialAd? = null
    private var rewardedAd: RewardedAd? = null
    private var isInterstitialLoading = false
    private var isRewardedLoading = false

    // Safety metrics
    private val appStartTime = System.currentTimeMillis()
    private var lastInterstitialShowTime = 0L
    private var tabSwitchCount = 0

    companion object {
        private const val TAG = "AdMobManager"
        private const val MIN_INTERSTITIAL_INTERVAL_MS = 120_000L // 120 seconds
        private const val INITIAL_SAFETY_DELAY_MS = 5_000L        // 5 seconds
        private const val MIN_TAB_SWITCHES_FOR_INTERSTITIAL = 2
    }

    init {
        // Preload interstitial and rewarded ads in background
        loadInterstitialAd()
        loadRewardedAd()
    }

    // =========================================================================
    // 1. BANNER AD: Fixed at bottom, loaded on start
    // =========================================================================
    fun setupBottomBanner(activity: Activity, container: FrameLayout) {
        val adView = AdView(activity).apply {
            adUnitId = context.getString(R.string.admob_banner_id)
            setAdSize(AdSize.BANNER)
            adListener = object : AdListener() {
                override fun onAdLoaded() {
                    Log.d(TAG, "Banner ad loaded successfully at bottom container")
                }
                override fun onAdFailedToLoad(error: LoadAdError) {
                    Log.w(TAG, "Banner ad failed to load: ${error.message}")
                }
            }
        }

        container.removeAllViews()
        container.addView(adView)

        val adRequest = AdRequest.Builder().build()
        adView.loadAd(adRequest)
    }

    // =========================================================================
    // 2. INTERSTITIAL AD: Background preload & strict safe trigger conditions
    // =========================================================================
    fun loadInterstitialAd() {
        if (interstitialAd != null || isInterstitialLoading) return

        isInterstitialLoading = true
        val adRequest = AdRequest.Builder().build()
        InterstitialAd.load(
            context,
            context.getString(R.string.admob_interstitial_id),
            adRequest,
            object : InterstitialAdLoadCallback() {
                override fun onAdLoaded(ad: InterstitialAd) {
                    interstitialAd = ad
                    isInterstitialLoading = false
                    Log.d(TAG, "Interstitial ad preloaded and ready in background")

                    ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                        override fun onAdDismissedFullScreenContent() {
                            interstitialAd = null
                            lastInterstitialShowTime = System.currentTimeMillis()
                            // Preload the next one immediately for future eligibility
                            loadInterstitialAd()
                        }

                        override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                            interstitialAd = null
                            isInterstitialLoading = false
                            loadInterstitialAd()
                        }
                    }
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    interstitialAd = null
                    isInterstitialLoading = false
                    Log.w(TAG, "Interstitial ad failed to load: ${loadAdError.message}")
                    // Retry with exponential backoff if needed
                    Handler(Looper.getMainLooper()).postDelayed({ loadInterstitialAd() }, 30_000L)
                }
            }
        )
    }

    /**
     * Called whenever user switches tabs.
     * Safe rules enforced:
     * - ONLY after 2nd tab click (tabSwitchCount >= 2)
     * - Minimum 5-second initial delay since app launched
     * - Max once every 120 seconds
     */
    fun onTabSwitched(activity: Activity) {
        tabSwitchCount++
        Log.d(TAG, "Tab switched. Total tab clicks: $tabSwitchCount")

        val currentTime = System.currentTimeMillis()
        val timeSinceAppStart = currentTime - appStartTime
        val timeSinceLastAd = currentTime - lastInterstitialShowTime

        val passesTabCount = tabSwitchCount >= MIN_TAB_SWITCHES_FOR_INTERSTITIAL
        val passesInitialDelay = timeSinceAppStart >= INITIAL_SAFETY_DELAY_MS
        val passesInterval = (lastInterstitialShowTime == 0L) || (timeSinceLastAd >= MIN_INTERSTITIAL_INTERVAL_MS)

        if (passesTabCount && passesInitialDelay && passesInterval) {
            interstitialAd?.let { ad ->
                Log.d(TAG, "All safe rules satisfied. Showing interstitial ad.")
                ad.show(activity)
            } ?: run {
                Log.d(TAG, "Interstitial ad not ready yet; continuing preload.")
                loadInterstitialAd()
            }
        } else {
            Log.d(TAG, "Interstitial skipped due to safe rate limiting: " +
                    "tabSwitchCount=$tabSwitchCount (need >= $MIN_TAB_SWITCHES_FOR_INTERSTITIAL), " +
                    "initialDelayPassed=$passesInitialDelay, " +
                    "intervalPassed=$passesInterval (${timeSinceLastAd / 1000}s / ${MIN_INTERSTITIAL_INTERVAL_MS / 1000}s)")
        }
    }

    // =========================================================================
    // 3. REWARDED AD: Triggered ONLY on "Unlock VIP Tips Today" button
    // =========================================================================
    fun loadRewardedAd() {
        if (rewardedAd != null || isRewardedLoading) return

        isRewardedLoading = true
        val adRequest = AdRequest.Builder().build()
        RewardedAd.load(
            context,
            context.getString(R.string.admob_rewarded_id),
            adRequest,
            object : RewardedAdLoadCallback() {
                override fun onAdLoaded(ad: RewardedAd) {
                    rewardedAd = ad
                    isRewardedLoading = false
                    Log.d(TAG, "Rewarded ad preloaded successfully")
                }

                override fun onAdFailedToLoad(loadAdError: LoadAdError) {
                    rewardedAd = null
                    isRewardedLoading = false
                    Log.w(TAG, "Rewarded ad failed to load: ${loadAdError.message}")
                }
            }
        )
    }

    /**
     * Shows rewarded ad specifically when user clicks "Unlock VIP Tips Today"
     */
    fun showRewardedForVipUnlock(
        activity: Activity,
        onRewardEarned: () -> Unit,
        onAdUnavailable: () -> Unit
    ) {
        val ad = rewardedAd
        if (ad != null) {
            ad.fullScreenContentCallback = object : FullScreenContentCallback() {
                override fun onAdDismissedFullScreenContent() {
                    rewardedAd = null
                    loadRewardedAd()
                }

                override fun onAdFailedToShowFullScreenContent(adError: AdError) {
                    rewardedAd = null
                    loadRewardedAd()
                    onAdUnavailable()
                }
            }

            ad.show(activity) { rewardItem ->
                Log.d(TAG, "User earned reward: ${rewardItem.type} (${rewardItem.amount})")
                onRewardEarned()
            }
        } else {
            loadRewardedAd()
            onAdUnavailable()
        }
    }
}
