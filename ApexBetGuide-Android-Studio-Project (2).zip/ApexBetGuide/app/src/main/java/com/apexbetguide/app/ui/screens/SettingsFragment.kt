package com.apexbetguide.app.ui.screens

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.apexbetguide.app.R
import com.apexbetguide.app.databinding.FragmentSettingsBinding

class SettingsFragment : Fragment() {

    private var _binding: FragmentSettingsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentSettingsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Privacy Policy Click
        binding.btnPrivacyPolicy.setOnClickListener {
            val url = getString(R.string.privacy_policy_url)
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
            startActivity(intent)
        }

        // Responsible Gambling Disclaimer Dialog
        binding.btnResponsibleGambling.setOnClickListener {
            AlertDialog.Builder(requireContext())
                .setTitle("18+ Responsible Sports Guidance")
                .setMessage("Apex Bet Guide provides mathematical and statistical models strictly for informational and entertainment purposes. We do not promote compulsive gambling. Please gamble responsibly.")
                .setPositiveButton("Understood", null)
                .show()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
