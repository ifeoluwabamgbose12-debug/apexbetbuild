package com.apexbetguide.app.ui.screens

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.apexbetguide.app.databinding.FragmentPredictionsBinding
import com.apexbetguide.app.ui.adapters.PredictionsAdapter

class PredictionsFragment : Fragment() {
    private var _binding: FragmentPredictionsBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentPredictionsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.rvPredictions.layoutManager = LinearLayoutManager(requireContext())
        binding.rvPredictions.adapter = PredictionsAdapter()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
