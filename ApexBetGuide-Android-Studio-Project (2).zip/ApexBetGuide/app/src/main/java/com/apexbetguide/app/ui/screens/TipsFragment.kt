package com.apexbetguide.app.ui.screens

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import com.apexbetguide.app.MainActivity
import com.apexbetguide.app.databinding.FragmentTipsBinding

class TipsFragment : Fragment() {

    private var _binding: FragmentTipsBinding? = null
    private val binding get() = _binding!!
    private var isVipUnlocked = false

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentTipsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        updateVipState()

        // Rewarded ad trigger ONLY on "Unlock VIP Tips Today" button
        binding.btnUnlockVip.setOnClickListener {
            val mainActivity = activity as? MainActivity ?: return@setOnClickListener
            
            mainActivity.adMobManager.showRewardedForVipUnlock(
                mainActivity,
                onRewardEarned = {
                    isVipUnlocked = true
                    updateVipState()
                    Toast.makeText(requireContext(), "🎉 VIP Tips Unlocked for Today!", Toast.LENGTH_LONG).show()
                },
                onAdUnavailable = {
                    Toast.makeText(requireContext(), "Ad not loaded yet. Please retry in a few seconds.", Toast.LENGTH_SHORT).show()
                }
            )
        }
    }

    private fun updateVipState() {
        if (isVipUnlocked) {
            binding.vipLockedContainer.visibility = View.GONE
            binding.vipUnlockedContainer.visibility = View.VISIBLE
            binding.btnUnlockVip.text = "VIP Access Unlocked for Today"
            binding.btnUnlockVip.isEnabled = false
        } else {
            binding.vipLockedContainer.visibility = View.VISIBLE
            binding.vipUnlockedContainer.visibility = View.GONE
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
