@rem Gradle wrapper script for Windows
@rem Run gradle with parameters
gradle %*
