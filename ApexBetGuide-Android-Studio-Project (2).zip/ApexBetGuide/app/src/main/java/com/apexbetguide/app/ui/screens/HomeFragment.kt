package com.apexbetguide.app.ui.screens

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import com.apexbetguide.app.databinding.FragmentHomeBinding
import com.apexbetguide.app.ui.adapters.MatchesAdapter

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View {
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Setup Welcome Card stats
        binding.tvWinRate.text = "84.6%"
        binding.tvTodayBankers.text = "3 / 3 Active"
        binding.tvAverageOdds.text = "2.15"

        // Setup Today's Matches List
        binding.rvTodayMatches.layoutManager = LinearLayoutManager(requireContext())
        binding.rvTodayMatches.adapter = MatchesAdapter()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
