package com.apexbetguide.app

import android.app.Application
import android.util.Log
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.RequestConfiguration

class ApexBetApplication : Application() {

    override fun onCreate() {
        super.onCreate()

        // Configure test devices for AdMob safety and ban prevention
        // Always include AdRequest.DEVICE_ID_EMULATOR during development and QA
        val testDeviceIds = listOf(
            AdRequest.DEVICE_ID_EMULATOR
            // Add your physical device hashed ID from Logcat here during testing:
            // "YOUR_DEVICE_HASHED_ID_FROM_LOGCAT"
        )

        val requestConfiguration = RequestConfiguration.Builder()
            .setTestDeviceIds(testDeviceIds)
            .build()
        MobileAds.setRequestConfiguration(requestConfiguration)

        // Initialize Google Mobile Ads SDK asynchronously
        MobileAds.initialize(this) { initializationStatus ->
            Log.d(TAG, "AdMob MobileAds initialized successfully")
        }
    }

    companion object {
        private const val TAG = "ApexBetApplication"
    }
}
